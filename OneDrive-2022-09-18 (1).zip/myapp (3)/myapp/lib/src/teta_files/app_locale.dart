mixin AppLocale {
  static const Map<String, dynamic> en = {};
}
