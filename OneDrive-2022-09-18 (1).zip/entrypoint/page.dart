import 'package:myapp/src/teta_files/imports.dart';
import 'package:myapp/auth/auth_state.dart';

import 'package:tcard/tcard.dart';

class PageEntryPoint extends StatefulWidget {
  const PageEntryPoint({
    Key? key,
  }) : super(key: key);

  @override
  _StateEntryPoint createState() => _StateEntryPoint();
}

class _StateEntryPoint extends State<PageEntryPoint> {
  var datasets = <String, dynamic>{};
  int index = 0;

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();

    TetaCMS.instance.analytics.insertEvent(
      TetaAnalyticsType.usage,
      'App usage: view page',
      <String, dynamic>{
        'name': "EntryPoint",
      },
      isUserIdPreferableIfExists: true,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      resizeToAvoidBottomInset: true,
      drawer: Drawer(
        child: NotificationListener<ScrollEndNotification>(
          onNotification: (final scrollEnd) {
            final metrics = scrollEnd.metrics;
            if (metrics.atEdge) {
              final isTop = metrics.pixels == 0;
              if (isTop) {
              } else {}
            }
            return true;
          },
          child: ListView(
            reverse: false,
            primary: true,
            physics: const AlwaysScrollableScrollPhysics(),
            children: [
              Padding(
                padding: const EdgeInsets.only(
                  left: 70,
                  top: 100,
                ),
                child: Text(
                  r'''ACCOUNT''',
                  style: GoogleFonts.poppins(
                    textStyle: TextStyle(
                      color: Color(0xFFFF6D00).withOpacity(1),
                      fontWeight: FontWeight.w400,
                      fontSize: 27,
                      fontStyle: FontStyle.normal,
                      decoration: TextDecoration.none,
                    ),
                  ),
                  textAlign: TextAlign.left,
                  textDirection: TextDirection.ltr,
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(
                  left: 70,
                  top: 30,
                ),
                child: Text(
                  r'''PAYMENT''',
                  style: GoogleFonts.poppins(
                    textStyle: TextStyle(
                      color: Color(0xFFFF6D00).withOpacity(1),
                      fontWeight: FontWeight.w400,
                      fontSize: 27,
                      fontStyle: FontStyle.normal,
                      decoration: TextDecoration.none,
                    ),
                  ),
                  textAlign: TextAlign.left,
                  textDirection: TextDirection.ltr,
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(
                  left: 70,
                  top: 30,
                ),
                child: Text(
                  r'''SETTINGS''',
                  style: GoogleFonts.poppins(
                    textStyle: TextStyle(
                      color: Color(0xFFFF6D00).withOpacity(1),
                      fontWeight: FontWeight.w400,
                      fontSize: 27,
                      fontStyle: FontStyle.normal,
                      decoration: TextDecoration.none,
                    ),
                  ),
                  textAlign: TextAlign.left,
                  textDirection: TextDirection.ltr,
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(
                  left: 70,
                  top: 30,
                ),
                child: Text(
                  r'''ACTIVITY''',
                  style: GoogleFonts.poppins(
                    textStyle: TextStyle(
                      color: Color(0xFFFF6D00).withOpacity(1),
                      fontWeight: FontWeight.w400,
                      fontSize: 27,
                      fontStyle: FontStyle.normal,
                      decoration: TextDecoration.none,
                    ),
                  ),
                  textAlign: TextAlign.left,
                  textDirection: TextDirection.ltr,
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(
                  left: 70,
                  top: 30,
                ),
                child: Text(
                  r'''ABOUT US''',
                  style: GoogleFonts.poppins(
                    textStyle: TextStyle(
                      color: Color(0xFFFF6D00).withOpacity(1),
                      fontWeight: FontWeight.w400,
                      fontSize: 27,
                      fontStyle: FontStyle.normal,
                      decoration: TextDecoration.none,
                    ),
                  ),
                  textAlign: TextAlign.left,
                  textDirection: TextDirection.ltr,
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(
                  left: 70,
                  top: 30,
                ),
                child: Text(
                  r'''FEEDBACK''',
                  style: GoogleFonts.poppins(
                    textStyle: TextStyle(
                      color: Color(0xFFFF6D00).withOpacity(1),
                      fontWeight: FontWeight.w400,
                      fontSize: 27,
                      fontStyle: FontStyle.normal,
                      decoration: TextDecoration.none,
                    ),
                  ),
                  textAlign: TextAlign.left,
                  textDirection: TextDirection.ltr,
                ),
              ),
            ],
          ),
        ),
      ),
      backgroundColor: const Color(0xFF000000),
      body: Stack(
        children: [
          Container(
            width: double.maxFinite,
            height: double.maxFinite,
            decoration: BoxDecoration(
              color: Color(0xFF000000).withOpacity(1),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(
                    left: 20,
                    top: 30,
                  ),
                  child: GestureDetector(onTap: () async {
                    if (_scaffoldKey.currentState != null) {
                      _scaffoldKey.currentState!.openDrawer();
                    }
                  },
                      Image.network(
                        r'''''',
                        width: 40,
                        height: 20,
                        fit: BoxFit.cover,
                      )),
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(
                        left: 90,
                        top: 20,
                      ),
                      child: Text(
                        r'''Token up !''',
                        style: GoogleFonts.acme(
                          textStyle: TextStyle(
                            color: Color(0xFFFE900F).withOpacity(1),
                            fontWeight: FontWeight.w400,
                            fontSize: 40,
                            fontStyle: FontStyle.normal,
                            decoration: TextDecoration.none,
                          ),
                        ),
                        textAlign: TextAlign.center,
                        textDirection: TextDirection.ltr,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(
                        left: 70,
                        top: 20,
                        right: 10,
                      ),
                      child: GestureDetector(onTap: () async {
                        await Navigator.push<void>(
                          context,
                          MaterialPageRoute(
                            builder: (context) => PageEntryPoint(),
                          ),
                        );
                      },
                          Image.network(
                            r'''''',
                            width: 40,
                            height: 40,
                            fit: BoxFit.cover,
                          )),
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    left: 150,
                    top: 150,
                  ),
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      color: Color(0xFF1D1D1D).withOpacity(1),
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(2),
                        topRight: Radius.circular(2),
                        bottomRight: Radius.circular(2),
                        bottomLeft: Radius.circular(2),
                      ),
                      border: null,
                    ),
                    child: SafeArea(
                      left: true,
                      top: false,
                      right: true,
                      bottom: false,
                      child: Text(
                        r'''New here.. ! ''',
                        style: GoogleFonts.acme(
                          textStyle: TextStyle(
                            color: Color(0xFFD68000).withOpacity(1),
                            fontWeight: FontWeight.w400,
                            fontSize: 20,
                            fontStyle: FontStyle.normal,
                            decoration: TextDecoration.none,
                          ),
                        ),
                        textAlign: TextAlign.center,
                        textDirection: TextDirection.ltr,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    left: 5,
                    top: 45,
                    bottom: 30,
                  ),
                  child: Text(
                    r'''trending on market''',
                    style: GoogleFonts.abrilFatface(
                      textStyle: TextStyle(
                        color: Color(0xFFA94D00).withOpacity(1),
                        fontWeight: FontWeight.w400,
                        fontSize: 16,
                        fontStyle: FontStyle.normal,
                        decoration: TextDecoration.underline,
                      ),
                    ),
                    textAlign: TextAlign.left,
                    textDirection: TextDirection.ltr,
                  ),
                ),
                const SizedBox(),
                Container(
                  width: double.maxFinite,
                  height: 40,
                  decoration: BoxDecoration(
                    color: Color(0xFF000000).withOpacity(1),
                  ),
                  child: Text(
                    r'''this product is still under beta testing ''',
                    style: GoogleFonts.poppins(
                      textStyle: TextStyle(
                        color: Color(0xFFFFFFFF).withOpacity(1),
                        fontWeight: FontWeight.w400,
                        fontSize: 16,
                        fontStyle: FontStyle.normal,
                        decoration: TextDecoration.none,
                      ),
                    ),
                    textAlign: TextAlign.left,
                    textDirection: TextDirection.ltr,
                  ),
                ),
              ],
            ),
          ),
          Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: Container(
                width: double.maxFinite,
                height: 80,
                decoration: BoxDecoration(
                  color: Color(0xFFFF4800).withOpacity(1),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(
                        left: 40,
                        top: 10,
                        right: 20,
                      ),
                      child: GestureDetector(onTap: () async {
                        await Navigator.push<void>(
                          context,
                          MaterialPageRoute(
                            builder: (context) => PageSearch(),
                          ),
                        );
                      },
                          Image.network(
                            r'''''',
                            width: 60,
                            height: 60,
                            fit: BoxFit.cover,
                          )),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(
                        left: 50,
                        top: 10,
                        right: 20,
                      ),
                      child: GestureDetector(onTap: () async {
                        await Navigator.push<void>(
                          context,
                          MaterialPageRoute(
                            builder: (context) => PageBuying(),
                          ),
                        );
                      },
                          Image.network(
                            r'''''',
                            width: 60,
                            height: 60,
                            fit: BoxFit.cover,
                          )),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(
                        left: 40,
                        top: 10,
                        right: 30,
                      ),
                      child: GestureDetector(onTap: () async {
                        await Navigator.push<void>(
                          context,
                          MaterialPageRoute(
                            builder: (context) => PageUserportfoilo(),
                          ),
                        );
                      },
                          Image.network(
                            r'''''',
                            width: 60,
                            height: 60,
                            fit: BoxFit.cover,
                          )),
                    ),
                  ],
                ),
              )),
        ],
      ),
    );
  }
}
